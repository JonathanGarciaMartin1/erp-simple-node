package com.sistemaumma.sistemanegocio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaNegocioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaNegocioApplication.class, args);
	}

}
