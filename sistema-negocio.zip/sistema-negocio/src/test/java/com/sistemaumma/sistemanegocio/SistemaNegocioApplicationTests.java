package com.sistemaumma.sistemanegocio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaNegocioApplicationTests {

	@Test
	void contextLoads() {
	}

}
